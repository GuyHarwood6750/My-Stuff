﻿<#

 FIX Scenario6 - Summit 2018 Troubleshooting remoting
                Richard Siddaway

                Rerun Endpoint
#>
Get-Content ./Fixscenario6.ps1

Enable-PSSessionConfiguration -Name Microsoft.PowerShell
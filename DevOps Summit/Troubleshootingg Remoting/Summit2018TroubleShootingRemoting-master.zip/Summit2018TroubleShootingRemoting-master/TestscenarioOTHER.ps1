﻿## view endpoint
Get-ChildItem -Path WSMan:\localhost\

Get-ChildItem -Path WSMan:\localhost\Service\
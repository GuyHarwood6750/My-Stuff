﻿<#

    Scenario5 - Summit 2018 Troubleshooting remoting
                Richard Siddaway

                Disable PowerShell remoting
#>

Disable-PSRemoting -Force
﻿<#

 FIX Scenario2 - Summit 2018 Troubleshooting remoting
                Richard Siddaway

                Rerun Enable-PSRemoting
#>
Get-Content ./Fixscenario2.ps1

Enable-PSRemoting -Force
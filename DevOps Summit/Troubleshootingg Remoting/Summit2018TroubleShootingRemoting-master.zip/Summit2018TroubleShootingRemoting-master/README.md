# Summit2018TroubleShootingRemoting
Slides and demonstration code from the 2018 PowerShell and DevOps Summit - TroubleShooting Remoting

﻿<#

    Scenario6 - Summit 2018 Troubleshooting remoting
                Richard Siddaway

                Disable endpoint
#>

Disable-PSSessionConfiguration -Name Microsoft.PowerShell
﻿<#

 FIX Scenario5 - Summit 2018 Troubleshooting remoting
                Richard Siddaway

                Rerun Enable-PSRemoting
#>
Get-Content ./Fixscenario5.ps1

Enable-PSRemoting -Force